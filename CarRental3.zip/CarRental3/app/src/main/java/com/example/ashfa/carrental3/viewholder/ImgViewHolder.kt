package com.example.ashfa.carrental3.viewholder

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.RecyclerView
import android.view.View
import com.example.ashfa.carrental3.R



        class ImgViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
